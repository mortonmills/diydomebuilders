let footer = document.getElementById("footer")

footer.innerHTML = `
    <hr>

  </body>
</html>
`
