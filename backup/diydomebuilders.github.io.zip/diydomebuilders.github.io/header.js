let header = document.getElementById("header")

header.innerHTML = ` 
  <body>

      <a href="../index.html">
        <h1>diydomebuilders <img src="../images/diyicon.png"></h1>
      </a>
`