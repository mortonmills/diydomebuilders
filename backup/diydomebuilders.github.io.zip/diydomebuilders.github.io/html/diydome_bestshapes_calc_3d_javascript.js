
    sphere
    radius = ( ( 3 * v) / ( 4 * Math.PI ) )**1/3 
    surface area = 4 * Math.PI * r**2
    base area = -   
    
    sphere 3/4
    radius = ( 2 * v**1/3 ) / ( 3**2/3 * Math.PI** 1/3  ) 
    sphere cap radius = a = Math.sqrt( ( r * 1.5 ) * ( 2 * r - ( r * 1.5 ) ) )     
    surface area = Math.PI * ( 2 * r * ( r * 1.5 ) + a**2 )  
    surface area (no base area) = 2 * Math.PI * r * ( r * 1.5 ) 
    base area = Math.PI * a**2
    
    sphere 1/2
    radius = &#8731;<span style="text-decoration = overline">( ( 3 * v ) / ( 2 * Math.PI ) ) </span> ///dfghdfgh
    surface area = ( 2 * Math.PI * r**2 ) + ( Math.PI * r**2) 
    surface area (no base area) =  2 * Math.PI * r**2  
    base area =  Math.PI * r**2  
    
    sphere 1/4
    radius = ( 2 * 3**1/3 * v**1/3 ) / ( 5**1/3 * Math.PI**1/3 ) 
    sphere cap radius = a = Math.sqrt( ( r * 0.5 ) * ( 2 * r - ( r * 0.5 ) ) ) 
    surface area =  Math.PI * ( 2 * r * ( r * 0.5 ) + a**2 ) 
    surface area (no base area) = 2 * Math.PI * r * ( r * 0.5 ) 
    base area = Math.PI * a**2  
    
    capsule
    radius = ( 3**1/3 * v**1/3 ) / ( 2**1/3 * 5**1/3 * Math.PI**1/3 ) 
    surface area = 2 * Math.PI * r * ( 2 * r + ( r * 2 ) )
    base area = -
    
    cylinder = 
    radius = ( v**1/3 ) / ( 2**1/3 * Math.PI**1/3 ) 
    surface area = 2 * Math.PI * r * ( ( r * 2 ) + r )
    base area = Math.PI * r**2 
    
    cone
    radius =  v**1/3  /  Math.PI**1/3 
    surface area = r * Math.PI * ( r + Math.sqrt((r*3)**2 + r**2) ) 
    base area = Math.PI * r**2  
    
    conical frustum
    radius
    surface area
    base area
    
    tetrahedron = Math.sqrt(2) ( 3 * v )**1/3    
    edge length
    surface area = e**2 * Math.sqrt(3) 
    base area = Math.sqrt(( ( e + e + e ) / 2 ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) )
    
    cube
    edge length = v**1/3 
    surface area = 6 * e**2 
    base area = e**2 
    
    octahedron
    edge length = 2**5/6 * ( 3 * ( v / 8 )**1/3 
    surface area = 2 * e**2 * Math.sqrt(3) 
    base area = Math.sqrt(( ( e + e + e ) / 2 ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) )
    
    dodecahedron
    edge length = 2**2/3 * ( v / ( 15 + Math.sqrt(245) )**1/3
    surface area = 3 * e**2 * Math.sqrt(25 + ( 10 * Math.sqrt( 5 )))  
    base area = e**2 / 4 * Math.sqrt(25 + ( 10 * Math.sqrt( 5 )))
    
    icosahedron
    edge length = ( 9 * ( v / 5 ) - 3 * Math.sqrt( 5 ) * ( v / 5 ) )**1/3 
    surface area = 5 * e**2 * Math.sqrt( 3 )
    base area = Math.sqrt(( ( e + e + e ) / 2 ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) * ( ( ( e + e + e ) / 2 ) - e ) ) 
    
    pyramid
    edge length = 3**1/3 * v**1/3 * 2**1/6
    surface area = ( 1 + Math.sqrt(3) ) * e**2 
    base area = e**2 
    
    rectangular prism
    edge length
    surface area
    base area
